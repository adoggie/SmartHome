#include "demo.h"
#include "iota_device.h"
#include "hw_json.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

ST_HUB_INFO g_stHubInfo={0};

HW_UINT g_uiBindFlag = HW_FALSE;
HW_UINT g_uiLoginFlag = HW_FALSE;

HW_UINT Cookie_AddDevice = 1;
HW_UINT Cookie_UpdateDeviceStatus = 2;
HW_UINT Cookie_ReportDeviceData = 3;
HW_UINT Cookie_RemoveDevice = 4;

HW_CHAR g_cDeviceId[50];

HW_INT main()
{
    int c;

    /*********************    Init AgentLite Resource   *********************************/
    HW_LOG_INF("*************** SAMPLE: AgentLite Init  *****************************");
    IOTA_Init(CONFIG_PATH, CONFIG_PATH);

    /*********************    Register BroadCast  *************************************/
    // Handle bind Result
    HW_BroadCastReg(IOTA_TOPIC_BIND_RSP, RESULT_HubBind);

    // Handle Unbind Event
    HW_BroadCastReg(IOTA_TOPIC_CMD_UNBIND_RECEIVE, SAMPLE_HubUnbind);

    // Handle Connect Event
    HW_BroadCastReg(IOTA_TOPIC_CONNECTED_NTY, RESULT_HubConnected);

    // Handle DisConnect Event
    HW_BroadCastReg(IOTA_TOPIC_DISCONNECT_NTY, RESULT_HubDisConnected);

    // Handle Add Device Result
    HW_BroadCastReg(IOTA_TOPIC_HUB_ADDDEV_RSP, RESULT_HubAddDevice);

    // Handle Report Device Status Result
    HW_BroadCastReg(IOTA_TOPIC_DEVUPDATE_RSP, RESULT_HubReportDeivceStatus);

    // Handle Report Device Data Result
    HW_BroadCastReg(IOTA_TOPIC_DATATRANS_REPORT_RSP, RESULT_HubReportDeivceData);

    // Handle Received Command
    HW_BroadCastReg(IOTA_TOPIC_SERVICE_COMMAND_RECEIVE, SAMPLE_HubReceiveCommand);

    // Handle Remove Device Result
    HW_BroadCastReg(IOTA_TOPIC_HUB_RMVDEV_RSP, RESULT_HubRemoveDevice); 
    /*********************    Register BroadCast  *************************************/

    memcpy(g_stHubInfo.pcIocmAddr, "183.1.3.133", strlen("183.1.3.133"));
    g_stHubInfo.uiIocmPort = 8943;

    /***********************  Binding Hub Flow  ***************************************/
    HW_LOG_INF("**************** SAMPLE: Bind Hub   ********************************");
    SAMPLE_HubBind();
    /***********************  Binding Hub Flow  ***************************************/

    // Wait Bind success
    while(!g_uiBindFlag)
    {
        HW_Sleep(5);
    }

    /***********************  Hub Login Flow  *****************************************/
    HW_LOG_INF("**************** SAMPLE: Hub Login  ********************************");
    SAMPLE_HubLogin();
    /***********************  Hub Login Flow  *****************************************/

    // Wait Login success
    while(!g_uiLoginFlag)
    {
        HW_Sleep(5);
    }

    /***********************   Hub Add Device Flow **************************************/
    HW_LOG_INF("**************** SAMPLE: Add Device   ********************************");
    SAMPLE_HubAddDevice();
    /***********************   Hub Add Device Flow **************************************/

    
    HW_Sleep(5);

    /***********************   Hub Device Status Report Flow ******************************/
    HW_LOG_INF("*************** SAMPLE: Report Device Status **************************");
    SAMPLE_HubReportDeivceStatus();
    /***********************   Hub Device Status Report Flow ******************************/
    
    HW_Sleep(5);

    /***********************   Hub Report Device Data Flow ********************************/
    HW_LOG_INF("*************** SAMPLE: Report Device Data  ***************************");
    SAMPLE_HubReportDeivceData();
    /***********************   Hub Report Device Data Flow ********************************/
    
    c = fgetc(stdin);
    printf("%c", c);

    if ('r' == c || 'R' == c)
    {
        c = fgetc(stdin);
        if ('\r' == c || '\n' == c) ;
    }
    
    
    /***********************   Hub Remove Device Flow ***********************************/
    HW_LOG_INF("*************** SAMPLE: Remove Device  ******************************");
    SAMPLE_HubRemoveDevice();
    /***********************   Hub Remove Device Flow ***********************************/

    HW_Sleep(5);

    /************************   Gateway Logout  Flow ************************************/
    HW_LOG_INF("*************** SAMPLE: Gateway Logout  *****************************");
    IOTA_Logout();
    /************************   Gateway Logout  Flow ************************************/

    HW_Sleep(5);

    /************************  AgentLite Destroy Flow  ***********************************/
    HW_LOG_INF("*************** SAMPLE: AgentLite Destroy  ***************************");
    IOTA_Destroy();
    /************************   AgentLite Destroy Flow  **********************************/

    return HW_OK;
    
}

/*****************************************
This sample shows how to Bind Hub.
******************************************/
HW_INT SAMPLE_HubBind()
{
    ST_IOTA_DEVICE_INFO  stDeviceInfo = {0};
    
    stDeviceInfo.pcNodeId = "222222222";
    stDeviceInfo.pcManufacturerName = "Huawei";
    stDeviceInfo.pcManufacturerId = "Huawei";
    stDeviceInfo.pcDeviceType = "Gateway";
    stDeviceInfo.pcModel = "HS3025";
    stDeviceInfo.pcProtocolType = "HuaweiM2M";

    // Set parameters
    IOTA_ConfigSetStr(EN_IOTA_CFG_IOCM_ADDR, g_stHubInfo.pcIocmAddr);   
    IOTA_ConfigSetUint(EN_IOTA_CFG_IOCM_PORT, g_stHubInfo.uiIocmPort);

    IOTA_Bind("222222222222", &stDeviceInfo);
    
    return HW_OK;
}

/*****************************************
This sample shows how to Login.
******************************************/
HW_INT SAMPLE_HubLogin()
{
    IOTA_ConfigSetStr(EN_IOTA_CFG_APPID, g_stHubInfo.pcAppID);
    IOTA_ConfigSetStr(EN_IOTA_CFG_DEVICEID, g_stHubInfo.pcDeviceID);  
    IOTA_ConfigSetStr(EN_IOTA_CFG_DEVICESECRET, g_stHubInfo.pcSecret);

    IOTA_ConfigSetStr(EN_IOTA_CFG_IOCM_ADDR, g_stHubInfo.pcIocmAddr);
    IOTA_ConfigSetUint(EN_IOTA_CFG_IOCM_PORT, g_stHubInfo.uiIocmPort);

    IOTA_ConfigSetStr(EN_IOTA_CFG_MQTT_ADDR, g_stHubInfo.pcIocmAddr);
    IOTA_ConfigSetUint(EN_IOTA_CFG_MQTT_PORT, g_stHubInfo.uiMqttPort);
	//IOTA_ConfigSetUint(EN_IOTA_CFG_MQTT_KEEPALIVE, 180);
	
    IOTA_Login();

    return HW_OK;
}

/*****************************************
This sample shows how to Handle Command.
******************************************/
HW_INT SAMPLE_HubReceiveCommand(HW_UINT uiCookie, HW_MSG pstMsg)
{
    HW_CHAR *pcDevId;
    HW_CHAR *pcReqId;
    HW_CHAR *pcServiceId;
    HW_CHAR *pcMethod;
    HW_BYTES *pbstrContent;

    pcDevId = HW_MsgGetStr(pstMsg,EN_IOTA_DATATRANS_IE_DEVICEID);
    pcReqId = HW_MsgGetStr(pstMsg,EN_IOTA_DATATRANS_IE_REQUESTID);
    pcServiceId = HW_MsgGetStr(pstMsg,EN_IOTA_DATATRANS_IE_SERVICEID);    
    pcMethod = HW_MsgGetStr(pstMsg,EN_IOTA_DATATRANS_IE_METHOD);
    pbstrContent = HW_MsgGetBstr(pstMsg,EN_IOTA_DATATRANS_IE_CMDCONTENT);
    
    if ((HW_NULL == pcDevId)
        ||(HW_NULL == pcReqId)
        ||(HW_NULL == pcServiceId)
        ||(HW_NULL == pcMethod)
        )
    {
        HW_LOG_ERR("SAMPLE: Receive Command Failed: pcDevId=%s, pcReqId=%s, pcServiceId=%s, pcMethod=%s.", pcDevId, pcReqId, pcServiceId, pcMethod); 
        return HW_ERR;
    }

    HW_LOG_ERR("SAMPLE: Receive Command Success: pcDevId=%s, pcReqId=%s, pcServiceId=%s, pcMethod=%s.", pcDevId, pcReqId, pcServiceId, pcMethod); 
    HW_LOG_ERR("SAMPLE: Receive Command Success: pbstrContent=%s", pbstrContent);    
    return HW_OK;
}

/*****************************************
This sample shows how to add a device.
******************************************/
HW_VOID SAMPLE_HubAddDevice()
{
    ST_IOTA_DEVICE_INFO  stDeviceInfo = {0};
    
    stDeviceInfo.pcNodeId = "1111111111111";
    stDeviceInfo.pcManufacturerName = "klha";
    stDeviceInfo.pcManufacturerId = "klha";
    stDeviceInfo.pcDeviceType = "AirSensor";
    stDeviceInfo.pcModel = "JZH-V10-D";
    stDeviceInfo.pcProtocolType = "modbus";
    IOTA_HubDeviceAdd(Cookie_AddDevice, &stDeviceInfo);

    return;   
}

/*****************************************
This sample shows how to report device status.
******************************************/
HW_INT SAMPLE_HubReportDeivceStatus()
{
    IOTA_DeviceStatusUpdate(Cookie_UpdateDeviceStatus, g_cDeviceId, "ONLINE", "NONE");

    return HW_OK;
}

/*****************************************
This sample shows how to report device data.
******************************************/
HW_INT SAMPLE_HubReportDeivceData()
{
    IOTA_ServiceDataReport(Cookie_ReportDeviceData, UGP_NULL, g_cDeviceId, "Battery", "{\"batteryLevel\":3.3}");

    return HW_OK;
}

/*****************************************
This sample shows how to remove a device.
******************************************/
HW_VOID SAMPLE_HubRemoveDevice()
{
    IOTA_HubDeviceRemove(Cookie_RemoveDevice, g_cDeviceId);

    return;   
}

/*****************************************
This sample shows how to remove a device.
******************************************/
HW_INT SAMPLE_HubUnbind(HW_UINT uiCookie, HW_MSG pstMsg)
{

    HW_LOG_INF("*************** SAMPLE: Hub unbind success  ***************************");
    g_uiBindFlag = HW_FALSE;
    g_uiLoginFlag = HW_FALSE;
    return HW_OK;
}

HW_INT RESULT_HubBind(HW_UINT uiCookie, HW_MSG pstMsg)
{
    HW_UINT uiRegRet;    

    uiRegRet = HW_MsgGetUint(pstMsg, EN_IOTA_BIND_IE_RESULT, EN_IOTA_BIND_RESULT_FAILED);
    if (EN_IOTA_BIND_RESULT_SUCCESS != uiRegRet)
    {
        HW_LOG_INF("*************** RESULT: Hub Bind Failed(%d)  ***************************", uiRegRet);
        return HW_ERR;
    }   

    memcpy(g_stHubInfo.pcAppID, HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_APPID), strlen(HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_APPID)));
    memcpy(g_stHubInfo.pcDeviceID, HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_DEVICEID), strlen(HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_DEVICEID)));
    memcpy(g_stHubInfo.pcSecret, HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_DEVICESECRET), strlen(HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_DEVICESECRET)));
    memcpy(g_stHubInfo.pcIocmAddr, HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_IOCM_ADDR), strlen(HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_IOCM_ADDR)));
    memcpy(g_stHubInfo.pcMqttAddr, HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_MQTT_ADDR), strlen(HW_MsgGetStr(pstMsg, EN_IOTA_BIND_IE_MQTT_ADDR)));
    g_stHubInfo.uiIocmPort  = HW_MsgGetUint(pstMsg, EN_IOTA_BIND_IE_IOCM_PORT,8943);
    g_stHubInfo.uiMqttPort  = HW_MsgGetUint(pstMsg, EN_IOTA_BIND_IE_MQTT_PORT,8883);

    g_uiBindFlag = HW_TRUE;
    return HW_OK;
}

HW_INT RESULT_HubConnected(HW_UINT uiCookie, HW_MSG pstMsg)
{

    HW_LOG_INF("*************** RESULT: Hub Login success  ***************************");

    g_uiLoginFlag = HW_TRUE;
       
    return HW_OK;
}

HW_INT RESULT_HubDisConnected(HW_UINT uiCookie, HW_MSG pstMsg)
{
    HW_UINT uiReason;

    g_uiLoginFlag = HW_FALSE;     
    
    uiReason = HW_MsgGetUint(pstMsg, EN_IOTA_LGN_IE_REASON, EN_IOTA_LGN_REASON_NULL); 

    HW_LOG_INF("*************** RESULT: Hub Login Failed(%d)  ***************************", uiReason);

    return HW_OK;
}

HW_INT RESULT_HubAddDevice(HW_UINT uiCookie, HW_MSG pstMsg)
{
    HW_UINT uiResult;

    if (uiCookie != Cookie_AddDevice)
    {
        HW_LOG_INF("*************** RESULT: Add Device Failed  ***************************");
        return HW_ERR;
    }

    uiResult = HW_MsgGetUint(pstMsg, EN_IOTA_HUB_IE_RESULT, 0);
    if (EN_IOTA_HUB_RESULT_SUCCESS != uiResult)
    {
        HW_LOG_ERR(" *************** RESULT: Add Device Failed(%d)  ***********************",uiResult); 
        return HW_ERR;
    }

    memcpy(g_cDeviceId, HW_MsgGetStr(pstMsg, EN_IOTA_HUB_IE_DEVICEID), strlen(HW_MsgGetStr(pstMsg, EN_IOTA_HUB_IE_DEVICEID)));

    HW_LOG_INF("*************** RESULT: Add Device Success  ***************************");

    return HW_OK;
}

HW_INT RESULT_HubRemoveDevice(HW_UINT uiCookie, HW_MSG pstMsg)
{
    HW_UINT uiResult;

    if (uiCookie != Cookie_RemoveDevice)
    {
        HW_LOG_INF("*************** RESULT: Remove Device Failed  ************************");
        return HW_ERR;
    }

    uiResult = HW_MsgGetUint (pstMsg, EN_IOTA_HUB_IE_RESULT,0);
    if (EN_IOTA_HUB_RESULT_SUCCESS != uiResult)
    {
        HW_LOG_ERR("*************** RESULT: Remove Device Failed(%d)  ********************", uiResult); 
        return HW_ERR;
    }

    memset(g_cDeviceId, 0, 50);

    HW_LOG_INF("*************** RESULT: Remove Device Success  *************************");

    return HW_OK;
}

HW_INT RESULT_HubReportDeivceStatus(HW_UINT uiCookie, HW_MSG pstMsg)
{
    HW_UINT uiResult;
    HW_CHAR *pcDeviceId;

    if (uiCookie != Cookie_UpdateDeviceStatus)
    {
        HW_LOG_INF("*************** RESULT: Report Device Status Failed *********************");
        return HW_ERR;
    }

    uiResult = HW_MsgGetUint (pstMsg, EN_IOTA_HUB_IE_RESULT,0);
    pcDeviceId = HW_MsgGetStr (pstMsg, EN_IOTA_HUB_IE_DEVICEID);
    
    if (EN_IOTA_HUB_RESULT_SUCCESS != uiResult)
    {
        HW_LOG_INF("*************** RESULT: Report Device Status Failed(%d), DevId(%s) *********************", uiResult, pcDeviceId);
        return HW_ERR;
    }

    HW_LOG_INF("*************** RESULT: Report Device Status Success DevId(%s) *********************", pcDeviceId);
    return HW_OK;
}

HW_INT RESULT_HubReportDeivceData(HW_UINT uiCookie, HW_MSG pstMsg)
{
    HW_UINT uiResult;

    if (uiCookie != Cookie_ReportDeviceData)
    {
        HW_LOG_INF("*************** RESULT: Report Device Data Failed *********************");
        return HW_ERR;
    }
    
    uiResult = HW_MsgGetUint (pstMsg, EN_IOTA_DATATRANS_IE_RESULT,HW_FAILED);
    if (HW_SUCCESS != uiResult)
    {
        HW_LOG_INF("*************** RESULT: Report Device Data Failed(%s) *********************", uiResult);
        return HW_ERR;
    }

    HW_LOG_INF("*************** RESULT: Report Device Data Success *********************");
    return HW_OK;
}

