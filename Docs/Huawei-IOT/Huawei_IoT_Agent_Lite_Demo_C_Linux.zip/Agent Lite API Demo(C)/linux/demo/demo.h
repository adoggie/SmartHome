#ifndef __HUB_DEMO_H__
#define __HUB_DEMO_H__

#include "hw_sys.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CONFIG_PATH "./"

typedef struct stru_ST_HUB_INFO
{
    HW_CHAR pcAppID[50];
    HW_CHAR pcDeviceID[50];
    HW_CHAR pcSecret[50];

    HW_CHAR pcIocmAddr[20];
    HW_UINT  uiIocmPort;
    HW_CHAR pcMqttAddr[20];
    HW_UINT  uiMqttPort;

    HW_BOOL uiLoginFlg;

}ST_HUB_INFO;

/*****************************************
This sample shows how to Bind Hub.
******************************************/
HW_INT SAMPLE_HubBind();

/*****************************************
This sample shows how to Login.
******************************************/
HW_INT SAMPLE_HubLogin();

/*****************************************
This sample shows how to Handle Command.
******************************************/
HW_INT SAMPLE_HubReceiveCommand(HW_UINT uiCookie, HW_MSG pstMsg);

/*****************************************
This sample shows how to add a device.
******************************************/
HW_VOID SAMPLE_HubAddDevice();

/*****************************************
This sample shows how to report device status.
******************************************/
HW_INT SAMPLE_HubReportDeivceStatus();

/*****************************************
This sample shows how to report device data.
******************************************/
HW_INT SAMPLE_HubReportDeivceData();

/*****************************************
This sample shows how to remove a device.
******************************************/
HW_VOID SAMPLE_HubRemoveDevice();

/*****************************************
This sample shows how to remove a device.
******************************************/
HW_INT SAMPLE_HubUnbind(HW_UINT uiCookie, HW_MSG pstMsg);

HW_INT RESULT_HubBind(HW_UINT uiCookie, HW_MSG pstMsg);

HW_INT RESULT_HubConnected(HW_UINT uiCookie, HW_MSG pstMsg);

HW_INT RESULT_HubDisConnected(HW_UINT uiCookie, HW_MSG pstMsg);

HW_INT RESULT_HubAddDevice(HW_UINT uiCookie, HW_MSG pstMsg);

HW_INT RESULT_HubRemoveDevice(HW_UINT uiCookie, HW_MSG pstMsg);

HW_INT RESULT_HubReportDeivceStatus(HW_UINT uiCookie, HW_MSG pstMsg);

HW_INT RESULT_HubReportDeivceData(HW_UINT uiCookie, HW_MSG pstMsg);

#ifdef __cplusplus
}
#endif

#endif /* __HUB_DEMO_H__ */
